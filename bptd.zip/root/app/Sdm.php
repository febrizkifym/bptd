<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Sdm extends Model
{
    protected $table = 'web_sdm';
    public $timestamps = false;
}
