<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class KegiatanPimpinan extends Model
{
    protected $table = "tv_kegiatan";
}
