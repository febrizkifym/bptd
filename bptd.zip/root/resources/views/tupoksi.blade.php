@extends('layouts/public')

@section('content')
<section id="sejarah">
    <div class="container">
        <h1>Tupoksi BPTD</h1>
        <hr>
        <div>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Placeat sit inventore, ullam vitae quos atque error et perferendis distinctio, fugit natus? Voluptatibus quae ex commodi earum, nobis reiciendis autem mollitia!</div>
        <div>Perferendis vero non, possimus alias consectetur repellat dolore excepturi odit eligendi pariatur itaque perspiciatis, a, dolorum odio dolor ea labore porro voluptas beatae tenetur aliquam inventore atque quos! Ipsum, voluptate.</div>
        <div>Aperiam voluptas, nostrum facere quaerat deleniti! Eos asperiores eligendi consequatur non odio cupiditate, officiis, error quidem explicabo, inventore rem eveniet. Tempora possimus consequatur distinctio! Doloremque, at ut excepturi. Eum, adipisci?</div>
    </div>
</section>
@endsection