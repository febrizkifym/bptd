<!DOCTYPE HTML>
<html lang="en">
<?php require_once('_template/head.php'); ?>
<body>
<?php require_once('_template/nav.php'); ?>
<!-- CONTENT -->


<!-- END CONTENT -->
<?php require_once('_template/footer.php'); ?>
<?php require_once('_template/js.php'); ?>
</body>
</html>