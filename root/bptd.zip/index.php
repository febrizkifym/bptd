<?php header('Location: public/');
?>