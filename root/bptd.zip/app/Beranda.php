<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Beranda extends Model
{
    protected $table = "web_beranda";
    public $timestamps = false;
}
