<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Satpel extends Model
{
    protected $table = 'web_satpel';
    public $timestamps = false;
}
